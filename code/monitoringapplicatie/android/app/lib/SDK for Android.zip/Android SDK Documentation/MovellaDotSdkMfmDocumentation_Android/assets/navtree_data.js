var NAVTREE_DATA =
[ [ "com.xsens.dot.android.sdk.mfm", "com/xsens/dot/android/sdk/mfm/package-summary.html", [ [ "Classes", null, [ [ "DotMfmManager", "com/xsens/dot/android/sdk/mfm/DotMfmManager.html", null, "" ], [ "DotMfmProcessor", "com/xsens/dot/android/sdk/mfm/DotMfmProcessor.html", null, "" ] ]
, "" ] ]
, "" ], [ "com.xsens.dot.android.sdk.mfm.interfaces", "com/xsens/dot/android/sdk/mfm/interfaces/package-summary.html", [ [ "Interfaces", null, [ [ "DotMfmCallback", "com/xsens/dot/android/sdk/mfm/interfaces/DotMfmCallback.html", null, "" ] ]
, "" ] ]
, "" ], [ "com.xsens.dot.android.sdk.mfm.models", "com/xsens/dot/android/sdk/mfm/models/package-summary.html", [ [ "Classes", null, [ [ "DotMfmResult", "com/xsens/dot/android/sdk/mfm/models/DotMfmResult.html", null, "" ] ]
, "" ] ]
, "" ] ]

;

