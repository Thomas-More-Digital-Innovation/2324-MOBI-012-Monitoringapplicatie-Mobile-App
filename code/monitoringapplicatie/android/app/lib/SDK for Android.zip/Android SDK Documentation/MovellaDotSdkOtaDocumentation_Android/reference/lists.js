var DATA = [
      { id:0, label:"com.xsens.dot.android.sdk.ota", link:"com/xsens/dot/android/sdk/ota/package-summary.html", type:"package" },
      { id:1, label:"com.xsens.dot.android.sdk.ota.DotOtaManager", link:"com/xsens/dot/android/sdk/ota/DotOtaManager.html", type:"class" },
      { id:2, label:"com.xsens.dot.android.sdk.ota.interfaces", link:"com/xsens/dot/android/sdk/ota/interfaces/package-summary.html", type:"package" },
      { id:3, label:"com.xsens.dot.android.sdk.ota.interfaces.DotOtaCallback", link:"com/xsens/dot/android/sdk/ota/interfaces/DotOtaCallback.html", type:"class" }

    ];
