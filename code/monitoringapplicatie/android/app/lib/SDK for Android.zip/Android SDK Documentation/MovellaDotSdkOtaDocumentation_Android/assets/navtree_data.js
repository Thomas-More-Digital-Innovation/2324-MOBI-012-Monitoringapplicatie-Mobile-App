var NAVTREE_DATA =
[ [ "com.xsens.dot.android.sdk.ota", "com/xsens/dot/android/sdk/ota/package-summary.html", [ [ "Classes", null, [ [ "DotOtaManager", "com/xsens/dot/android/sdk/ota/DotOtaManager.html", null, "" ] ]
, "" ] ]
, "" ], [ "com.xsens.dot.android.sdk.ota.interfaces", "com/xsens/dot/android/sdk/ota/interfaces/package-summary.html", [ [ "Interfaces", null, [ [ "DotOtaCallback", "com/xsens/dot/android/sdk/ota/interfaces/DotOtaCallback.html", null, "" ] ]
, "" ] ]
, "" ] ]

;

