var NAVTREE_DATA =
[ [ "com.xsens.dot.android.sdk", "com/xsens/dot/android/sdk/package-summary.html", [ [ "Classes", null, [ [ "DotSdk", "com/xsens/dot/android/sdk/DotSdk.html", null, "" ] ]
, "" ] ]
, "" ], [ "com.xsens.dot.android.sdk.events", "com/xsens/dot/android/sdk/events/package-summary.html", [ [ "Classes", null, [ [ "DotData", "com/xsens/dot/android/sdk/events/DotData.html", null, "" ] ]
, "" ] ]
, "" ], [ "com.xsens.dot.android.sdk.interfaces", "com/xsens/dot/android/sdk/interfaces/package-summary.html", [ [ "Interfaces", null, [ [ "DotCiCallback", "com/xsens/dot/android/sdk/interfaces/DotCiCallback.html", null, "" ], [ "DotDeviceCallback", "com/xsens/dot/android/sdk/interfaces/DotDeviceCallback.html", null, "" ], [ "DotMeasurementCallback", "com/xsens/dot/android/sdk/interfaces/DotMeasurementCallback.html", null, "" ], [ "DotRecordingCallback", "com/xsens/dot/android/sdk/interfaces/DotRecordingCallback.html", null, "" ], [ "DotScannerCallback", "com/xsens/dot/android/sdk/interfaces/DotScannerCallback.html", null, "" ], [ "DotSyncCallback", "com/xsens/dot/android/sdk/interfaces/DotSyncCallback.html", null, "" ], [ "SettingsCallback", "com/xsens/dot/android/sdk/interfaces/SettingsCallback.html", null, "" ] ]
, "" ] ]
, "" ], [ "com.xsens.dot.android.sdk.models", "com/xsens/dot/android/sdk/models/package-summary.html", [ [ "Classes", null, [ [ "DotDevice", "com/xsens/dot/android/sdk/models/DotDevice.html", null, "" ], [ "DotPayload", "com/xsens/dot/android/sdk/models/DotPayload.html", null, "" ], [ "DotProductId", "com/xsens/dot/android/sdk/models/DotProductId.html", null, "" ], [ "DotRecordingFileInfo", "com/xsens/dot/android/sdk/models/DotRecordingFileInfo.html", null, "" ], [ "DotResetData", "com/xsens/dot/android/sdk/models/DotResetData.html", null, "" ], [ "DotSyncManager", "com/xsens/dot/android/sdk/models/DotSyncManager.html", null, "" ], [ "FilterProfileInfo", "com/xsens/dot/android/sdk/models/FilterProfileInfo.html", null, "" ], [ "VersionModel", "com/xsens/dot/android/sdk/models/VersionModel.html", null, "" ] ]
, "" ], [ "Enums", null, [ [ "DotRecordingState", "com/xsens/dot/android/sdk/models/DotRecordingState.html", null, "" ], [ "FilterProfileInfo.PropertyType", "com/xsens/dot/android/sdk/models/FilterProfileInfo.PropertyType.html", null, "" ] ]
, "" ] ]
, "" ], [ "com.xsens.dot.android.sdk.recording", "com/xsens/dot/android/sdk/recording/package-summary.html", [ [ "Classes", null, [ [ "DotRecordingManager", "com/xsens/dot/android/sdk/recording/DotRecordingManager.html", null, "" ] ]
, "" ] ]
, "" ], [ "com.xsens.dot.android.sdk.settings", "com/xsens/dot/android/sdk/settings/package-summary.html", [ [ "Classes", null, [ [ "DotSettingsManager", "com/xsens/dot/android/sdk/settings/DotSettingsManager.html", null, "" ] ]
, "" ], [ "Enums", null, [ [ "DotResetResults", "com/xsens/dot/android/sdk/settings/DotResetResults.html", null, "" ] ]
, "" ] ]
, "" ], [ "com.xsens.dot.android.sdk.utils", "com/xsens/dot/android/sdk/utils/package-summary.html", [ [ "Classes", null, [ [ "DotCompatibleUtil", "com/xsens/dot/android/sdk/utils/DotCompatibleUtil.html", null, "" ], [ "DotDebugger", "com/xsens/dot/android/sdk/utils/DotDebugger.html", null, "" ], [ "DotLogger", "com/xsens/dot/android/sdk/utils/DotLogger.html", null, "" ], [ "DotParser", "com/xsens/dot/android/sdk/utils/DotParser.html", null, "" ], [ "DotScanner", "com/xsens/dot/android/sdk/utils/DotScanner.html", null, "" ] ]
, "" ] ]
, "" ] ]

;

